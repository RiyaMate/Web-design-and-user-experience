A two-page website of Investment management.
 CSS Grid layout, Flexbox, and SASS/SCSS Features. minimum of TWO CSS Grid layout and TWO Flexbox layout in your pages wherever it fits.
Implemented All the below SASS Features
Variables,
Custom Properties
Nesting
Interpolation
Placeholder Selectors
Mixins
Functions
